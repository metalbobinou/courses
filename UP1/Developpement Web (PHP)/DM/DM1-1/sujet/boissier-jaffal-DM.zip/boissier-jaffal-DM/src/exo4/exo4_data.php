<?php

$line1 = array("X", "O", "A");
$line2 = array("X", "X", "O");
$line3 = array("O", "O", "X");

$game[] = $line1;
$game[] = $line2;
$game[] = $line3;

/*
$game[0] = array("X", "X", "X");
$game[1] = array("O", "O", "X");
$game[2] = array("X", "X", "O");
*/

?>