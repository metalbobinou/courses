<?php

function my_NormalisationNom($filenames)
{
  $output = "";
  // TODO

  return ($output);
}

?>
