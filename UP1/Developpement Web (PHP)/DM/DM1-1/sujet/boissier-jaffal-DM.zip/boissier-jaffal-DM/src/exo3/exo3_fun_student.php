<?php

function my_CalculTVA($input_table)
{
  $output = "";
  // TODO

  return ($output);
}

?>
