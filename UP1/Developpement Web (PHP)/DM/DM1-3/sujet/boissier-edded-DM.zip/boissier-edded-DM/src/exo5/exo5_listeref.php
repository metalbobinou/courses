<?php

$ReferenceList[] = array("Marc", "Acin", "05-05-1998");
$ReferenceList[] = array("Charles", "Attan", "20-06-1997");
$ReferenceList[] = array("Eva", "Bien", "23-02-1998");
$ReferenceList[] = array("Jean", "Bombeur", "17-01-1999");
$ReferenceList[] = array("Jean", "Bonnot", "1997");
$ReferenceList[] = array("Claire", "Hon", "14-07-1997");
$ReferenceList[] = array("Lydie", "Le", "02-03-1997");
$ReferenceList[] = array("Julie", "Tali", "18-12-1998");
$ReferenceList[] = array("Oreste", "Torrent", "22-04-1998");
$ReferenceList[] = array("Elena", "Turelle", "08-10-1998");

?>
