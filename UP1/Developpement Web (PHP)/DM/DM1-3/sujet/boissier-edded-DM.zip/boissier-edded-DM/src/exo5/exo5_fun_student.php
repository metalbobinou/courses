<?php

function my_Loginisation($ReferenceList, $RequestList)
{
  $output = "";
  // TODO

  return ($output);
}

?>
