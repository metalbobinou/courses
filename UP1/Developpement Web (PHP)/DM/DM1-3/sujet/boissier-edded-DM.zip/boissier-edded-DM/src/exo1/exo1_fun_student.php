<?php

function my_Calculette($nb1, $nb2, $op)
{
  $output = "";
  // TODO

  return ($output);
}

?>
