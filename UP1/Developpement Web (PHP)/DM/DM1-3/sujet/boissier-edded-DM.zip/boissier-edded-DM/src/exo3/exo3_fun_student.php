<?php

function my_Reduction($input_table, $reduction)
{
  $output = "";
  // TODO

  return ($output);
}

?>
