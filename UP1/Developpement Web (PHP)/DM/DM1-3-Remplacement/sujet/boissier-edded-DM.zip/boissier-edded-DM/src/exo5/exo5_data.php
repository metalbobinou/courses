<?php

$filenames[] = "IMG_3.jpg";
$filenames[] = "IMG_02.JPG";
$filenames[] = "IMG_0005.jpg";
$filenames[] = "IMG_8976.JPG";
$filenames[] = "img_42.png";
$filenames[] = "picture35.BMP";

?>
