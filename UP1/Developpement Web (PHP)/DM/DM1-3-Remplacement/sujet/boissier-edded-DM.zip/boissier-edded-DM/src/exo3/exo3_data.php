<?php

$tab1["ID_Client"] = 42421337;
$tab1["Date"] = new DateTime('2006-06-06');
$tab1["ID_Facture"] = 456789;
$tab1["Montant_TTC"] = 200;
$data[] = $tab1;

$tab1["ID_Client"] = 36153615;
$tab1["Date"] = new DateTime('2018-05-30');
$tab1["ID_Facture"] = 123456;
$tab1["Montant_TTC"] = 123;
$data[] = $tab1;

?>