<?php

$line1 = array(0, "42", "A");
$line2 = array("-", "U", 13);
//$line3 = array('W', 0, "T");

$line1 = array(0, 42, 1);
$line2 = array(8, 9, 13);
//$line3 = array(4, 0, 5);

$mat2=array();
$line=array();

$mat3[]=$mat2;
$mat3[]=$line;


$matrix[] = $line1;
$matrix[] = $line2;
//$matrix[] = $line3;

$matrix = $mat2;

?>