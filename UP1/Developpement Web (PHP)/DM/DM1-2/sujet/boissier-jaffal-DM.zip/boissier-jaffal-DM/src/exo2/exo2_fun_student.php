<?php

function my_Square($size)
{
  $output = "";
  //TODO

  return ($output);
}

?>
