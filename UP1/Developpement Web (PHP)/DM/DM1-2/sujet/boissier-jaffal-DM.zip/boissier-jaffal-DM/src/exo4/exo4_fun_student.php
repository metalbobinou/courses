<?php

function my_Transposee($matrix)
{
  $output = "";
  // TODO

  return ($output);
}

?>
