<?php

$line1 = array(0, 42, 1);
$line2 = array(8, 9, 13);

$matrix[] = $line1;
$matrix[] = $line2;

?>