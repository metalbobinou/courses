<?php

$RequestList[] = array("Eva", "Bien", "23-02-1998");
$RequestList[] = array("Jean", "Bombeur", "24-12-2000");
$RequestList[] = array("Jean", "Bonnot", "1997");
$RequestList[] = array("Julie", "Tali", "18-12-1998");
$RequestList[] = array("Clément", "Thine", "13-04-1998");

?>
